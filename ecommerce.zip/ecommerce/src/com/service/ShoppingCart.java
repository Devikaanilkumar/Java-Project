package com.service;

import com.app.Product;
import com.data.Inventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class ShoppingCart {
    private List<Product> cartItems = new ArrayList<>();
    Inventory inventory = new Inventory();

    public void addToCart(Product product, int quantity) {
        for (int i = 0; i < quantity; i++) {
            cartItems.add(product);
        }
    }

    public void viewCart() {
        System.out.println("Shopping Cart:");
        for (Product product : cartItems) {
            System.out.println(product.getProductName() + " - $" + product.getPrice());
        }
    }

    public void Display() {
        System.out.println("Available Products:");
        for (Product product : inventory.getProducts()) {
            System.out.println("Product Name : " + product.getProductName() + ", Product ID : " + product.getProductId() + ", Price : " + product.getPrice());
        }
    }

   

    public void removeFromCart(int productId, int quantity) {
        int removedCount = 0;
        Iterator<Product> iterator = cartItems.iterator();
        
        while (iterator.hasNext() && removedCount < quantity) {
            Product product = iterator.next();
            if (product.getProductId() == productId) {
                iterator.remove();
                removedCount++;
            }
        }
    }

    public void checkout() {
        double total = 0;
        for (Product product : cartItems) {
            total += product.getPrice();
        }
        System.out.println("Total amount: $" + total);
        cartItems.clear();
        System.out.println("Thank you for your purchase!");
    }
}
